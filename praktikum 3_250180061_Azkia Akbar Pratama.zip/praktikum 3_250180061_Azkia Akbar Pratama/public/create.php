<?php
// public/create.php - CREATE (Form Tambah Produk + Validasi + PRG)
require_once __DIR__ . '/../config/db.php';

$name = "";
$category = "Umum";
$price = "";
$stock = "";
$errors = [];

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    // 1. Normalisasi Input
    $name = trim($_POST["name"] ?? "");
    $category = trim($_POST["category"] ?? "") ?: "Umum";
    $rawPrice = $_POST["price"] ?? "";
    $rawStock = $_POST["stock"] ?? "";

    $price = filter_var($rawPrice, FILTER_VALIDATE_FLOAT);
    $stock = filter_var($rawStock, FILTER_VALIDATE_INT);

    // 2. Validasi Server-Side
    if (mb_strlen($name) < 3) {
        $errors["name"] = "Nama produk minimal 3 karakter.";
    } else {
        // Cek keunikan nama produk
        $stmtCheck = $pdo->prepare("SELECT id FROM products WHERE name = :name");
        $stmtCheck->execute(["name" => $name]);
        if ($stmtCheck->fetch()) {
            $errors["name"] = "Nama produk sudah digunakan. Gunakan nama lain.";
        }
    }

    if ($price === false || $price <= 0) {
        $errors["price"] = "Harga harus berupa angka lebih besar dari 0.";
    }

    if ($stock === false || $stock < 0) {
        $errors["stock"] = "Stok harus berupa angka tidak boleh negatif.";
    }

    // 3. Simpan jika tidak ada error
    if (empty($errors)) {
        $stmt = $pdo->prepare("INSERT INTO products (name, category, price, stock) VALUES (:name, :category, :price, :stock)");
        $stmt->execute([
            "name" => $name,
            "category" => $category,
            "price" => $price,
            "stock" => $stock
        ]);

        // Pola PRG (Post-Redirect-Get) untuk mencegah resubmit
        header("Location: index.php?status=created");
        exit;
    }
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tambah Produk - Product Manager</title>
    <link rel="stylesheet" href="assets/style.css">
</head>
<body>
    <div class="container">
        <header>
            <h1>Tambah Produk Baru</h1>
            <a href="index.php" class="btn btn-secondary">← Kembali</a>
        </header>

        <div class="form-card">
            <form action="create.php" method="POST">
                <div class="form-group">
                    <label for="name">Nama Produk</label>
                    <input type="text" id="name" name="name" class="form-control" 
                           value="<?= htmlspecialchars($name, ENT_QUOTES, 'UTF-8') ?>" minlength="3" required>
                    <?php if (isset($errors["name"])): ?>
                        <div class="error-text"><?= htmlspecialchars($errors["name"], ENT_QUOTES, 'UTF-8') ?></div>
                    <?php endif; ?>
                </div>

                <div class="form-group">
                    <label for="category">Kategori</label>
                    <input type="text" id="category" name="category" class="form-control" 
                           value="<?= htmlspecialchars($category, ENT_QUOTES, 'UTF-8') ?>" required>
                    <?php if (isset($errors["category"])): ?>
                        <div class="error-text"><?= htmlspecialchars($errors["category"], ENT_QUOTES, 'UTF-8') ?></div>
                    <?php endif; ?>
                </div>

                <div class="form-group">
                    <label for="price">Harga (Rp)</label>
                    <input type="number" id="price" name="price" step="0.01" min="1" class="form-control" 
                           value="<?= htmlspecialchars($price, ENT_QUOTES, 'UTF-8') ?>" required>
                    <?php if (isset($errors["price"])): ?>
                        <div class="error-text"><?= htmlspecialchars($errors["price"], ENT_QUOTES, 'UTF-8') ?></div>
                    <?php endif; ?>
                </div>

                <div class="form-group">
                    <label for="stock">Jumlah Stok</label>
                    <input type="number" id="stock" name="stock" min="0" class="form-control" 
                           value="<?= htmlspecialchars($stock, ENT_QUOTES, 'UTF-8') ?>" required>
                    <?php if (isset($errors["stock"])): ?>
                        <div class="error-text"><?= htmlspecialchars($errors["stock"], ENT_QUOTES, 'UTF-8') ?></div>
                    <?php endif; ?>
                </div>

                <div style="margin-top: 24px; display: flex; gap: 10px;">
                    <button type="submit" class="btn btn-primary" style="flex: 1;">Simpan Produk</button>
                    <a href="index.php" class="btn btn-secondary">Batal</a>
                </div>
            </form>
        </div>
    </div>
</body>
</html>
