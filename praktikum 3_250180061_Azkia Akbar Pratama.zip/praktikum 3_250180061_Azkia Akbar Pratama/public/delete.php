<?php
// public/delete.php - DELETE (Penghapusan Produk dengan Proteksi CSRF + PRG)
require_once __DIR__ . '/../config/db.php';

session_start();

// 1. Pastikan Request Berupa POST
if ($_SERVER["REQUEST_METHOD"] !== "POST") {
    http_response_code(405);
    exit("Method tidak diizinkan.");
}

// 2. Proteksi Token CSRF
$sessionCsrf = $_SESSION["csrf"] ?? "";
$postCsrf = $_POST["csrf"] ?? "";

if (!hash_equals($sessionCsrf, $postCsrf)) {
    http_response_code(403);
    exit("Akses ditolak: Token CSRF tidak valid.");
}

// 3. Validasi Input ID
$id = filter_input(INPUT_POST, "id", FILTER_VALIDATE_INT);

if ($id) {
    // 4. Jalankan Query Delete dengan Prepared Statement
    $stmt = $pdo->prepare("DELETE FROM products WHERE id = :id");
    $stmt->execute(["id" => $id]);
}

// 5. Redirect kembali ke index.php (Pola PRG)
header("Location: index.php?status=deleted");
exit;
