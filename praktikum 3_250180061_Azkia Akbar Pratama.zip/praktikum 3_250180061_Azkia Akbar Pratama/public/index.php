<?php
// public/index.php - READ (Menampilkan Daftar Produk)
require_once __DIR__ . '/../config/db.php';

session_start();
// Inisialisasi token CSRF di session jika belum ada
$_SESSION["csrf"] ??= bin2hex(random_bytes(32));

// Ambil semua data produk dari database (terbaru lebih dulu)
$stmt = $pdo->query("SELECT id, name, category, price, stock, created_at FROM products ORDER BY id DESC");
$products = $stmt->fetchAll();

// Pesan notifikasi dari alur PRG (Post-Redirect-Get)
$status = $_GET["status"] ?? "";
$statusMessage = "";
$statusType = "success";

if ($status === "created") {
    $statusMessage = "Produk berhasil disimpan.";
} elseif ($status === "updated") {
    $statusMessage = "Produk berhasil diperbarui.";
} elseif ($status === "deleted") {
    $statusMessage = "Produk berhasil dihapus.";
} elseif ($status === "not_found") {
    $statusMessage = "Produk tidak ditemukan.";
    $statusType = "danger";
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Product Manager - Daftar Produk</title>
    <link rel="stylesheet" href="assets/style.css">
</head>
<body>
    <div class="container">
        <header>
            <div>
                <h1>Product Manager</h1>
                <p style="color: #64748b; margin-top: 4px;">Kelola inventoris produk dengan aman dan mudah</p>
            </div>
            <a href="create.php" class="btn btn-primary">+ Tambah Produk</a>
        </header>

        <?php if (!empty($statusMessage)): ?>
            <div class="alert alert-<?= $statusType ?>">
                <?= htmlspecialchars($statusMessage, ENT_QUOTES, "UTF-8") ?>
            </div>
        <?php endif; ?>

        <?php if (empty($products)): ?>
            <div class="empty-state">
                <p>Belum ada produk yang tersimpan. Klik <strong>+ Tambah Produk</strong> untuk menambahkan.</p>
            </div>
        <?php else: ?>
            <div class="products">
                <?php foreach ($products as $p): ?>
                    <div class="card">
                        <div class="card-body">
                            <span class="badge"><?= htmlspecialchars($p["category"], ENT_QUOTES, "UTF-8") ?></span>
                            <h3><?= htmlspecialchars($p["name"], ENT_QUOTES, "UTF-8") ?></h3>
                            <div class="price">Rp <?= number_format($p["price"], 0, ",", ".") ?></div>
                            <div class="stock">Stok: <strong><?= (int)$p["stock"] ?></strong> unit</div>
                        </div>
                        <div class="actions">
                            <a href="edit.php?id=<?= $p["id"] ?>" class="btn btn-warning">Edit</a>
                            
                            <!-- Form Delete POST + CSRF Protection -->
                            <form method="POST" action="delete.php" onsubmit="return confirm('Yakin ingin menghapus produk ini?');">
                                <input type="hidden" name="id" value="<?= $p["id"] ?>">
                                <input type="hidden" name="csrf" value="<?= $_SESSION["csrf"] ?>">
                                <button type="submit" class="btn btn-danger">Hapus</button>
                            </form>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>
    </div>
</body>
</html>
